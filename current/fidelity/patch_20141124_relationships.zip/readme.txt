Patch for query definition editor UI
Patch for reporting query definition relationships

Deployment:

Stop Reporting Services

Alter Reporting Schema:
Add new columns to RELATIONSHIPS table:
PRIORITY (NUMBER) default 0
JOIN_TYPE (NUMBER) default 0

Copy /UI/Amakozi.Reporting.Tridion.Editor to <Reporting Install>/UI/Amakozi.Reporting.Tridon.Editor
Copy /UI/Amakozi.Reporting.Tridion.Model to <Reporting Install>/UI/Amakozi.Reporting.Tridion.Model
Copy /UI/Amakozi.Reporting.Tridion.Model/bin to %TRIDION_HOME%/web/webui/webroot/bin
Copy /Core to <Reporting Install>/Core

Edit %TRIDION_HOME%/web/webui/webroot/configuration/system.config
Increment "modification" attribute value on the following element:
/Configuration/servicemodel/server

Restart the Reporting service

Release Notes:
A relationship now has two additional properties: priority and join type.
Priority sets the order in which the joins (inner, left, right) are added to the query.

