﻿Type.registerNamespace("Amakozi.Reporting.Tridion.Model");

Amakozi.Reporting.Tridion.Model.QueryDefinition = function QueryDefinition(id)
{
    Tridion.OO.enableInterface(this, "Amakozi.Reporting.Tridion.Model.QueryDefinition");
    this.addInterface("Amakozi.Reporting.Tridion.Model.Item", [id]);
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getItemType = function QueryDefinition$getItemType() {
    return $const.ItemType.AMARPTQRYDEF;
};
Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getItemIcon = function QueryDefinition$getItemIcon() {
    return "ama.rptqrydef";
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getOrganizationalItemId = function QueryDefinition$getOrganizationalItemId() {
    return "ama:0-rptqrydeffolder";
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getDatasources = function QueryDefinition$getDatasources()
{
    var arr = [];
    var doc = this.getXmlDocument();
    var nodes = $xml.selectNodes(doc, "//tcm:Data/tcm:Datasources/tcm:Datasource", $const.Namespaces);
    for (var i = 0; i < nodes.length; i++)
    {
        var obj = { uid: nodes[i].getAttribute("id"), name: nodes[i].getAttribute("name"), Columns: [] };
        var columnNodes = $xml.selectNodes(nodes[i], "tcm:Column", $const.Namespaces);
        for (var j = 0; j < columnNodes.length; j++)
        {
            obj.Columns.push({ uid: columnNodes[j].getAttribute("id"), name: columnNodes[j].getAttribute("name") });
        }
        arr.push(obj);
    }
    return arr;
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getRelationships = function QueryDefinition$getRelationships()
{
    var arr = [];
    var doc = this.getXmlDocument();
    var nodes = $xml.selectNodes(doc, "//tcm:Data/tcm:Relationships/tcm:Relationship", $const.Namespaces);
    for (var i = 0; i < nodes.length; i++)
    {
        var obj =
        { 
            source_datasource_uid: nodes[i].getAttribute("sourceDatasource"),
            target_datasource_uid: nodes[i].getAttribute("targetDatasource"),
            source_column: nodes[i].getAttribute("sourceColumn"),
            target_column: nodes[i].getAttribute("targetColumn"),
            join_type: nodes[i].getAttribute("joinType"),
            priority: nodes[i].getAttribute("priority")
        }
        arr.push(obj);
    }
    return arr;
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.setRelationships = function QueryDefinition$setRelationships(relationships, context, suppressEvent)
{
    var rel = [];
    for (var i = 0; i < relationships.length; i++)
    {
        rel.push("<tcm:Relationship sourceDatasource=\"{0}\" targetDatasource=\"{1}\" sourceColumn=\"{2}\" targetColumn=\"{3}\" joinType=\"{4}\" priority=\"{5}\" xmlns:tcm=\"http://www.tridion.com/ContentManager/5.0\" />".format(relationships[i].source.datasource, relationships[i].target.datasource, relationships[i].source.column, relationships[i].target.column, relationships[i].jointype, relationships[i].priority));
    }
    return this.updateInnerXml("//tcm:Data/tcm:Relationships", rel.join(""), context, suppressEvent);
}

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.getFilters = function QueryDefinition$getFilters()
{
    var arr = [];
    var doc = this.getXmlDocument();
    var nodes = $xml.selectNodes(doc, "//tcm:Data/tcm:Filters/tcm:Filter", $const.Namespaces);
    for (var i = 0; i < nodes.length; i++)
    {
        var obj =
        {
            datasource_uid: nodes[i].getAttribute("datasourceid"),
            filter_type: nodes[i].getAttribute("type"),
            filter_column: nodes[i].getAttribute("columnid"),
            filter_value: nodes[i].getAttribute("value")
        }
        arr.push(obj);
    }
    return arr;
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.setFilters = function QueryDefinition$setFilters(filters, context, suppressEvent)
{
    var rel = [];
    for (var i = 0; i < filters.length; i++)
    {
        rel.push("<tcm:Filter datasourceid=\"{0}\" type=\"{1}\" columnid=\"{2}\" value=\"{3}\" xmlns:tcm=\"http://www.tridion.com/ContentManager/5.0\" />".format(filters[i].datasource, filters[i].type, filters[i].column, filters[i].filter_value));
    }
    return this.updateInnerXml("//tcm:Data/tcm:Filters", rel.join(""), context, suppressEvent);
}


Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.insertDatasource = function QueryDefinition$insertDatasource(datasource)
{
    var self = this;
    var success = function (xml)
    {
        self.appendXml("//tcm:Data/tcm:Datasources", "<tcm:Datasource id=\"{0}\" name=\"{1}\" xmlns:tcm=\"http://www.tridion.com/ContentManager/5.0\"/>".format(datasource.uid, $dom.escape(datasource.name)));
        self.appendXml("//tcm:Data/tcm:Content", xml);
        self.fireEvent("datasourceinserted", { newgroup: xml });
    }
    Amakozi.Reporting.Tridion.Model.AmakoziReportingService.GetSystemList("datasourcefields", datasource.uid, success)
};

Amakozi.Reporting.Tridion.Model.QueryDefinition.prototype.removeDatasource = function QueryDefinition$removeDatasource(datasource)
{
    this.removeXml("//tcm:Data/tcm:Datasources/tcm:Datasource[@id='{0}']".format(datasource.uid));
    this.removeXml("//tcm:Data/tcm:Content/tcm:FieldGroup[@id='{0}']".format(datasource.uid));
    this.fireEvent("datasourceremoved", { groupid: datasource.uid });
};