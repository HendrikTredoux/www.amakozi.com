﻿Type.registerNamespace("Amakozi.Reporting.Commands");

Amakozi.Reporting.Commands.InsertDatasource = function Commands$InsertDatasource(name)
{
    Type.enableInterface(this, "Amakozi.Reporting.Commands.InsertDatasource");
    this.addInterface("Tridion.Cme.Command", [name]);
    this.properties.selectionPopup = null;
    this.properties.selection = null;
};


Amakozi.Reporting.Commands.InsertDatasource.prototype.isEnabled = function InsertDatasource$isEnabled(selection)
{
    var item = $models.getItem(selection.getItem(0));
    if (item)
    {
        return !item.isReadOnly() && !item.isLoading() && item.getItemType() == $const.ItemType.AMARPTQRYDEF;
    }
    return false;
};

Amakozi.Reporting.Commands.InsertDatasource.prototype._execute = function InsertDatasource$_execute(selection)
{
    if (RelationshipMapper)
    {

        var p = this.properties;
        var listDatasources = $models.getItem($const.TCMROOT).getList(new Tridion.ContentManager.ListFilter, undefined, undefined, "Amakozi.Reporting.Tridion.Model.DatasourceList");
        var targetDatasources = RelationshipMapper.datasources;
        if (targetDatasources.length > 0)
        {
            var targetDatasourceArray = [];
            targetDatasourceArray.push("<tcm:ListItems xmlns:tcm=\"http://www.tridion.com/ContentManager/5.0\">");
            for (var i = 0; i < targetDatasources.length; i++)
            {
                targetDatasourceArray.push("<tcm:Item ID=\"{0}\" Title=\"{1}\" />".format(targetDatasources[i].uid, $dom.escape(targetDatasources[i].name)));
            }
            targetDatasourceArray.push("</tcm:ListItems>")
            var targetDatasourceList = targetDatasourceArray.join("");
        }
        p.selectionPopup = $popup.create(
		$config.expandEditorPath("/Views/Popups/InsertDatasource.aspx"),
		"width=600px,height=350px,resizable=0",
		{
		    targetDatasourceList: targetDatasourceList
		});

        $evt.addEventHandler(p.selectionPopup, "unload", this.getDelegate(this._onInsertPopupUnloaded));
        $evt.addEventHandler(p.selectionPopup, "apply", this.getDelegate(this._onInsertPopupApply));
        p.selectionPopup.open();
        p.selection = selection;

    } else
    {
        $messages.registerWarning($localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "NoRelationshipMapper"), $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "RelationshipMapperRequired"), true, true)
    }

};

Amakozi.Reporting.Commands.InsertDatasource.prototype._onInsertPopupUnloaded = function InsertDatasource$_onInsertPopupUnloaded()
{
    var p = this.properties;
    if (p.selectionPopup)
    {
        $evt.removeAllEventHandlers(p.selectionPopup);
        p.selectionPopup.dispose();
        p.selectionPopup = null;
    }
    p.selection = null;
}

Amakozi.Reporting.Commands.InsertDatasource.prototype._onInsertPopupApply = function InsertDatasource$_onInsertPopupApply(event)
{
    var sel = (event && event.data) ? event.data : null;
    if (sel)
    {
        RelationshipMapper.addDatasource(sel.sourceDatasourceId, sel.sourceDatasourceTitle, sel.sourceColumnCollection, sel.relationship ? [sel.relationship] : null);
    }
}