﻿// Mapper
var RelationShipMapper;

(function ($) {

    // Internal Functions
    var add_datasource_to_preview, remove_datasource_from_preview, get_datasource_element_from_preview;
    var add_relationship_to_preview, remove_relationship_from_preview;
    var datasource_clicked, relationship_create_form_clicked, filter_create_form_clicked;

    // Long check for shorter code ...
    var long_check_relationship_valid = function(rel_obj, source_datasource_uid, target_datasource_uid, source_column, target_column) {

        return (rel_obj.source.datasource === source_datasource_uid && rel_obj.source.column === source_column && rel_obj.target.datasource === target_datasource_uid && rel_obj.target.column === target_column) ||
            (rel_obj.source.datasource === target_datasource_uid && rel_obj.source.column === target_column && rel_obj.target.datasource === source_datasource_uid && rel_obj.target.column === source_column);

    };

    // Api OBJ
    var api_obj = {};

    // Config
    api_obj.config_path_to_remove_image = '/WebUI/Editors/Reporting/Controls/RelationshipMapper/relationship_line_remove_icon.png';
    api_obj.filter_types = [
        {
            "name": "Regex",
            "uid": 0
        },
        {
            "name": "LessThan",
            "uid": 1
        },
        {
            "name": "MoreThan",
            "uid": 2
        },
        {
            "name": "LessEqualThan",
            "uid": 3
        },
        {
            "name": "MoreEqualThan",
            "uid": 4
        }
    ];

    // Local Vars
    api_obj.current_id_count = 0;
    api_obj.is_meta_fields_open =false;
    api_obj.current_selected_datasource = 'aaa';

    api_obj.datasources = [];
    api_obj.columns = [];
    api_obj.filters = [];
    api_obj.relationships = [];

    // Events that we can call
    api_obj.datasource_filter_created = null;
    api_obj.datasource_filter_removed = null;
    api_obj.datasource_relationship_created = null;
    api_obj.datasource_relationship_removed = null;
    api_obj.datasource_added = null;
    api_obj.datasource_removed = null;
    api_obj.datasource_updated = null;

    /**
    * Shows a Confirmation Box that asks YES / NO.  
    *
    * This is then overriden in Tridion to provide the Tridion Box
    **/
    api_obj.confirmDialog = function(text) {
        return confirm(text);
    };

    /**
    * Returns the Current Count for adding ID to Object
    **/
    api_obj.getUID = function(){
    
        api_obj.current_id_count += 1;
        return api_obj.current_id_count;

    };

    /**
    * Add Relationship
    **/
    api_obj.addRelationship = function(source_datasource_uid, target_datasource_uid, source_column, target_column, join_type, priority) {
        
        // Get if it does not already exist ?
        var matching_rels = _.filter(api_obj.relationships, function(rel_obj) {

            return long_check_relationship_valid(rel_obj, source_datasource_uid, target_datasource_uid, source_column, target_column);

        });


        // IF it does not we add
        if(!matching_rels || matching_rels.length === 0) {

            // Get the UID of the rel
            var rel_uid = api_obj.getUID();

            // Rel Obj created
            var rel_obj = {
                
                'uid': rel_uid,
                'source': {
                    'datasource': source_datasource_uid,
                    'column': source_column
                },
                'target': {
                    'datasource': target_datasource_uid,
                    'column': target_column
                },
                'jointype': join_type,
                'priority': priority
            };
            
            // Add to List
            api_obj.relationships.push(rel_obj);

            // Should we execute a callback ?
            if(api_obj.datasource_relationship_created) api_obj.datasource_relationship_created(rel_obj);

        }

        // And ... Render
        api_obj.render();

    };

    /**
    * Removes a Relationship by it's Parameters
    **/
    api_obj.removeRelationship = function(source_datasource_uid, target_datasource_uid, source_column, target_column) {
        
        // Remove the relationships that match this.
        api_obj.relationships = _.reject(api_obj.relationships, function(rel_obj) {

            var result = long_check_relationship_valid(rel_obj, source_datasource_uid, target_datasource_uid, source_column, target_column);
            if(api_obj.datasource_relationship_removed && result) api_obj.datasource_relationship_removed(rel_obj);
            return result;

        });

        // And Render
        api_obj.render();

    };

    /**
    * Removes Relations by Datasource
    **/
    api_obj.removeRelationshipsByDatasource = function(datasource_uid) {

        // Remove the relationships that match this.
        api_obj.relationships = _.reject(api_obj.relationships, function(rel_obj) {

            var result = '' + rel_obj.source.datasource === '' + datasource_uid || '' + rel_obj.target.datasource === '' + datasource_uid;
            if(api_obj.datasource_relationship_removed && result) api_obj.datasource_relationship_removed(rel_obj);
            return result;

        });

        // And Render
        api_obj.render();

    };

    /**
    * Removes Relations by Datasource
    **/
    api_obj.removeRelationshipByUid = function(relationship_uid) {

        // Remove the relationships that match this.
        api_obj.relationships = _.reject(api_obj.relationships, function(rel_obj) {

            var result = '' + rel_obj.uid == '' + relationship_uid;
            if(api_obj.datasource_relationship_removed && result) api_obj.datasource_relationship_removed(rel_obj);
            return result;

        });

        // And Render
        api_obj.render();

    };

    /**
    * Add filter
    **/
    api_obj.addFilter = function(datasource_uid, filter_type, filter_column, filter_value) {
        
        // Get if it does not already exist ?
        var matching_filters = _.filter(api_obj.filters, function(filter_obj) {

            return filter_obj.type == filter_type && filter_obj.filter_value == filter_value && filter_obj.datasource == datasource_uid;

        });

        // IF it does not we add
        if(!matching_filters || matching_filters.length === 0) {

             // Get the UID of the rel
            var filter_uid = api_obj.getUID();

            // Filter Obj
            var filter_obj = {
                
                'uid': filter_uid,
                'type': filter_type,
                'column': filter_column,
                'filter_value': filter_value,
                'datasource': datasource_uid

            };
            
            // Add to List
            api_obj.filters.push(filter_obj);

            // Should we execute a callback ?
            if(api_obj.datasource_filter_created) api_obj.datasource_filter_created(filter_obj);

        }

        // And ... Render
        api_obj.render();

    };

    /**
    * Removes a Relationship by it's Parameters
    **/
    api_obj.removeFilterByUid = function(filter_uid) {
        
        // Remove the relationships that match this.
        api_obj.filters = _.reject(api_obj.filters, function(filter_obj) {

            var result = '' + filter_obj.uid == '' + filter_uid;
            if(api_obj.datasource_filter_removed && result) api_obj.datasource_filter_removed(filter_obj);
            return result;

        });

        // And Render
        api_obj.render();

    };

    /**
    * Removes Relations by Datasource
    **/
    api_obj.removeFiltersByDatasource = function(datasource_uid) {

        // Remove the relationships that match this.
        api_obj.filters = _.reject(api_obj.filters, function(filter_obj) {

            return filter_obj.datasource = datasource_uid;

        });

        // And Render
        api_obj.render();

    };

    /**
    * Updates the Information of the Datasource
    **/
    api_obj.updateDatasource = function(uid, name, columns) {

        _.each(api_obj.datasources, function(element, index, list) {
        
            if(api_obj.datasources[index].uid === uid) {
                
                // Update the Object
                api_obj.datasources[index].name = name;
                api_obj.datasources[index].columns = columns;

            }

        });

        // And ... Render
        api_obj.render();

    };

    /**
    * Adds another datasource
    **/
    api_obj.addDatasource = function(uid, name, columns, relationships, filters) {

        // Get if it does not already exist ?
        var matching_filters = _.filter(api_obj.datasources, function(ds_obj) {

            return ds_obj.uid === uid;

        });

        // IF it does not we add
        if(!matching_filters || matching_filters.length === 0) {

            // Filter Obj
            var ds_obj = {
                
                'uid': uid,
                'name': name,
                'columns': columns

            };
            
            // Add to List
            api_obj.datasources.push(ds_obj);

            // Add the Relatioships if any
            if(relationships && relationships.length > 0)
            {
                for(var i = 0; i < relationships.length; i++) {
                   
                    api_obj.addRelationship(relationships[i].source_datasource_uid, relationships[i].target_datasource_uid, relationships[i].source_column, relationships[i].target_column, relationships[i].join_type, relationships[i].priority);

                }
            }

            // Add Filters if any
            if(filters && filters.length > 0) {
                for(var i = 0; i < filters.length; i++) {
                   
                    api_obj.addFilter(filters[i].datasource_uid, filters[i].filter_type, filters[i].filter_column, filters[i].filter_value);

                }
            }

            // Should we execute a callback ?
            if(api_obj.datasource_added) api_obj.datasource_added(ds_obj);

        } else return matching_filters[0];

        // And ... Render
        api_obj.render();

    };

    /**
    * Removes a Datasource by it's UID
    **/
    api_obj.removeDatasource = function(uid) {

        // Removes the Datasource's Relationships
        api_obj.removeRelationshipsByDatasource(uid);

        // Remove the Datasource from the List
        api_obj.datasources = _.reject(api_obj.datasources, function(ds_obj) {

            // Check
            var expr = ds_obj.uid === uid;

            // Do callback
            if(expr && api_obj.datasource_removed) api_obj.datasource_removed(ds_obj);

            // Return !
            return expr;

        });

        // Remove Relationships
        api_obj.removeFiltersByDatasource(uid);
        api_obj.removeRelationshipsByDatasource(uid);

        // And ... Render
        api_obj.render();

    };

    api_obj.removeDatasourceAndRelationship = function() {

        if(api_obj.datasources.length > 1) {

            // Check any of the connected datasources now have 0 relationships
            var target_count = _.groupBy(api_obj.relationships, function(rel_obj) { return '' + rel_obj.target.datasource; });
            var source_count = _.groupBy(api_obj.relationships, function(rel_obj) { return '' + rel_obj.source.datasource; });

            for(var i = 0; i < api_obj.datasources.length; i++) {

                if('' + api_obj.datasources[i].uid in target_count || '' + api_obj.datasources[i].uid in source_count)
                {

                    api_obj.datasource_updated(api_obj.relationships);

                }
                else
                {
                    if(api_obj.datasources.length > 1) {

                        // Hide the sidebar if this is the current control
                        if(api_obj.current_selected_datasource && '' + api_obj.datasources[i].uid == '' + api_obj.current_selected_datasource.uid) {

                            api_obj.current_selected_datasource = "aaa";
                            $(".relationship_meta_fields_close_btn").click();

                        }

                        // Remove DS
                        api_obj.removeDatasource('' + api_obj.datasources[i].uid);

                    }
                }
            }
        }
    }

    /**
    * Validates the Preview
    * 
    * Checks for a few things
    * -> All Datasources must have 1 relationship if more than 1 is present
    * -> All Columns from relationships and inputs should exist
    **/
    api_obj.validate = function(){
        

        
    };
    
    /**
    * Renders the Preview
    **/
    api_obj.render = function(){
    
        // Check for Datasources Else Nothing ...
        if(_.size(api_obj.datasources) > 0) {

            // Remove all Pipes
            jsPlumb.reset();

            // Set our Defaults
            jsPlumb.importDefaults({
                // default drag options
                DragOptions: { cursor: 'pointer', zIndex: 2000 },
                // default to blue at one end and green at the other
                // the overlays to decorate each connection with.  note that the label overlay uses a function to generate the label text; in this
                // case it returns the 'labelText' member that we set on each connection in the 'init' method below.
                ConnectionOverlays: [
                            ["Label", {
                                location: 0.1,
                                id: "label",
                                cssClass: "aLabel"
                            }]
                        ],
                ConnectorZIndex: 5
            });

            // Setup our styles of connection
            var connectorPaintStyle = {
                lineWidth: 5,
                strokeStyle: "#deea18",
                joinstyle: "round",
                outlineColor: "white",
                outlineWidth: 7
            };
            var connectorHoverStyle = {
                    lineWidth: 7,
                    strokeStyle: "#2e2aF8"
                };

            // Clear DS Listing
            $("#listing_relationship_preview_block").html('');

            // Loop each Datasource and:
            // -> Add element representing datasource
            for(var i = 0; i < api_obj.datasources.length; i++) {

                // Get ID
                var ds_element_id = 'preview_ds_' + api_obj.datasources[i].uid;

                var selectClass = "";

                if(api_obj.current_selected_datasource.uid && api_obj.current_selected_datasource.uid === api_obj.datasources[i].uid){
                    selectClass = "relationship_highlighted";
                }

                // Add Element to Page
                $("#listing_relationship_preview_block").append('<a id="' + ds_element_id + '" ds-id="' + api_obj.datasources[i].uid + '" href="javascript:void(0);" class="relationship_preview_datasource_block ' + selectClass + '">' + api_obj.datasources[i].name + '</a>');

            }

            // Bind for click on Datasources
            $("a.relationship_preview_datasource_block").unbind();
            $("a.relationship_preview_datasource_block").click(function(){
            
                // For Local reference
                var btn  = this;
                var clickID = "#" + $(this).attr('id');
                //alert(clickID);

                // Get Data
                var ds_uid = $(btn).attr('ds-id');
                var datasource = _.find(api_obj.datasources, function(ds_obj) { return ds_obj.uid === ds_uid; });
                relationships = _.filter(api_obj.relationships, function(rel_obj){ return rel_obj.source.datasource == datasource.uid || rel_obj.target.datasource == datasource.uid; });
                filters = _.filter(api_obj.filters, function(filter_obj){ return filter_obj.datasource == datasource.uid; });

                // Show the Meta bar after the click
                $("#relationship_preview_block").addClass('relationship_view_block_moved_to_side');
                $("#relationship_meta_fields").show();

                // Set current datasource
                api_obj.current_selected_datasource = datasource;


                // Set Title
                $("#relationship_meta_fields_title > h3").text(datasource.name);

                // Rerender Pipes
                api_obj.render();

                // Highlight selected datascource - Fanie
                $(clickID).addClass("relationship_highlighted");

                // Add Info to the Meta

            });

            // Bind on Meta to Close
            $(".relationship_meta_fields_close_btn").unbind();
            $(".relationship_meta_fields_close_btn").click(function(e){
            
                // Show the Meta bar after the click
                $("#relationship_meta_fields").hide();
                $("#relationship_preview_block").removeClass('relationship_view_block_moved_to_side');

                // Rerender Pipes
                api_obj.render();

                // Return False
                e.preventDefault();
                return false;
            
            });

            // Bind the Datasource Remove Button
            $(".relationship_meta_fields_remove_btn").unbind();
            $(".relationship_meta_fields_remove_btn").click(function(e){

                if(api_obj.current_selected_datasource) {

                    // Remove from Lists
                    api_obj.removeDatasource(api_obj.current_selected_datasource.uid);
            
                    // Show the Meta bar after the click
                    $(".relationship_meta_fields_close_btn").click();

                    // Rerender Pipes
                    api_obj.render();

                }
            
                // Not going anywhere
                e.preventDefault();
                return false;
            
            });

            // Bind back buttons when editing or adding rels or filters
            $(".relationship_meta_back_to_list").unbind();
            $(".relationship_meta_back_to_list").click(function(e){
            
                // Hide Edit / Create Screens
                $(".meta_side_block").hide();
                $("#relationship_meta_fields_list").show();
                $("#relationship_meta_btn_bottom_sidebar").show();

                // Prevent
                e.preventDefault();
                return false;

            });

            // Handle Relationship Saves
            $(".relationship_save_btn").unbind();
            $(".relationship_save_btn").click(function(e){

                // Prevent
                e.preventDefault();

                // Get Values
                var source_datasource = api_obj.current_selected_datasource.uid;
                var source_column = $("#relationship_meta_save_source_column").val();
                var target_datasource = $("#relationship_meta_save_target_datasource").val();
                var target_column = $("#relationship_meta_save_target_column").val();
                var join_type = $("#relationship_meta_save_join_type").val();
                var priority = $("#relationship_meta_save_priority").val();
                // Add as Relationship
                api_obj.addRelationship(source_datasource, target_datasource, source_column, target_column, join_type, priority);

                // Update Data Object - Fanie
                api_obj.datasource_updated(api_obj.relationships);

                // And go back !
                $(".relationship_meta_back_to_list").click();

                // Nothing !
                return false;

            });

            // Bind to the Filter Save Button
            $(".relationship_save_filter_btn").unbind();
            $(".relationship_save_filter_btn").click(function(e){

                // Prevent
                e.preventDefault();

                // Get Values
                var datasource_for_filter = api_obj.current_selected_datasource.uid;
                var column_for_filter = $("#relationship_meta_filter_save_column").val();
                var filter_type = $("#relationship_meta_filter_save_type").val().toLowerCase();
                var filter_expression = $("#relationship_meta_filter_save_expression").val();

                // Add as Relationship
                api_obj.addFilter(datasource_for_filter, filter_type, column_for_filter, filter_expression);

                // Update Data Object - Fanie
                api_obj.datasource_updated(api_obj.filters);


                // And go back !
                $(".relationship_meta_back_to_list").click();

                // Nothing !
                return false;
            
            });

            // Add Items to the Meta Sidebar
            if(api_obj.current_selected_datasource)
            {
                
                var ds_info = api_obj.GetDatasourceInfoByUid(api_obj.current_selected_datasource.uid);

                if(ds_info)
                {
                
                    // Clear HTML of Lists
                    $("#meta_list_relationships .meta_info_item_list").html('');
                    $("#meta_list_filters .meta_info_item_list").html('');

                    if(api_obj.datasources.length > 0) {

                        // Add Relationships
                        for(var i = 0; i < ds_info.relationships.length; i++) {

                            var join_type = ds_info.relationships[i].jointype;
                            var priority = ds_info.relationships[i].priority;
                            var source_column;
                            var source_datasource = _.find(api_obj.datasources, function(ds_obj){
                            
                                if(ds_obj.uid == ds_info.relationships[i].source.datasource) {

                                    // Find the Column
                                    var column_obj = _.find(ds_obj.columns, function(col_obj) {
                                    
                                        return col_obj.uid == ds_info.relationships[i].source.column;
                                    
                                    });

                                    if(column_obj)
                                    {

                                        source_column = column_obj;
                                        return true;

                                    } else return false;

                                }

                                return false;
                                
                            });

                            var target_column;
                            var target_datasource = _.find(api_obj.datasources, function(ds_obj){
                            
                                if(ds_obj.uid == ds_info.relationships[i].target.datasource) {

                                    // Find the Column
                                    var column_obj = _.find(ds_obj.columns, function(col_obj) {
                                    
                                        return col_obj.uid == ds_info.relationships[i].target.column;
                                    
                                    });

                                    if(column_obj)
                                    {

                                        target_column = column_obj;
                                        return true;

                                    } else return false;
                                }

                                return false;
                                
                            });
                            
                            if(source_column && target_column)
                            {
                                var target_datasource = api_obj.GetDatasourceInfoByUid(ds_info.relationships[i].target.datasource);
                                var source_datasource = api_obj.GetDatasourceInfoByUid(ds_info.relationships[i].source.datasource);
                                $("#meta_list_relationships .meta_info_item_list").append('<li><span class="edit_relationship">' +  source_datasource.datasource.name + '.' + source_column.name + ' ' + join_type + ' JOIN(' + priority + ') to ' + target_datasource.datasource.name + '.' + target_column.name + '</span><span class="delete_relationship" data-rel-id="' + ds_info.relationships[i].uid + '" href="javascript:void(0);"><img src="' + api_obj.config_path_to_remove_image + '" /></span></li><br><br><br>');

                            }

                        }

                        $("#meta_list_relationships .meta_info_item_add_btn").show();

                    } else {

                        $("#meta_list_relationships .meta_info_item_list").append('<li>Add another Datasource to Manage Relationships</li>');
                        $("#meta_list_relationships .meta_info_item_add_btn").hide();

                    }

                    // Delete Relationship
                    $("#meta_list_relationships .meta_info_item_list span.delete_relationship").click(function(){
                        
                        var current_rel_uid = $(this).attr('data-rel-id');

                        if(api_obj.confirmDialog('Are you sure you want to remove this relationship?')) {

                            api_obj.removeRelationshipByUid(current_rel_uid);
                            api_obj.removeDatasourceAndRelationship();

                        }
                        
                    });

                    // Edit Relationship
                    $("#meta_list_relationships .meta_info_item_list span.edit_relationship").click(function(){
                        
                            //TODO: add functionality to edit relatioships
                        
                    });

                    // Add Filter
                    for(var i = 0; i < ds_info.filters.length; i++) {

                        $("#meta_list_filters .meta_info_item_list").append('<li><span class="edit_filter" href="javascript:void(0);">' + ds_info.filters[i].type + " - " + ds_info.filters[i].filter_value + '</span><span class="delete_filter" data-rel-id="' + ds_info.filters[i].uid + '" href="javascript:void(0);"><img src="' + api_obj.config_path_to_remove_image + '" /></span></li><br><br><br>');

                    }

                    // Delete filter
                    $("span.delete_filter").click(function(){
                        
                        var current_fil_uid = $(this).attr('data-rel-id');

                        if(api_obj.confirmDialog('Really remove the Filter of ' + api_obj.current_selected_datasource.name + ' ?')) {

                            api_obj.removeFilterByUid(current_fil_uid);
                            api_obj.datasource_updated(api_obj.filters);

                        }
                        
                    });


                    // Edit Filter
                    $("span.edit_filter").click(function(){
                        
                        // TODO: Filter Edit Functionality.
                        
                    });

                }

            }

            // Bind to Add Button for Relationship and Filters
            $("#meta_list_relationships .meta_info_item_add_btn").click(function(e) {

                // Hide List
                $(".meta_side_block").hide();
                $("#relationship_meta_fields_add_relationship").show();

                // Clear and Populate Inputs
                $("#relationship_meta_save_source_column").html('');
                $("#relationship_meta_save_target_datasource").html('');
                $("#relationship_meta_save_target_column").html('');

                // Add all our columns
                for(var i = 0; i < api_obj.current_selected_datasource.columns.length; i++) {

                    // Add as Option
                    $("#relationship_meta_save_source_column").append('<option value="' + api_obj.current_selected_datasource.columns[i].uid + '">' + api_obj.current_selected_datasource.columns[i].name + '</option>');
                        
                }

                var first_datasource;

                // Loop each of the Datasources expect us and add to list
                for(var i = 0; i < api_obj.datasources.length; i++) {

                    if(api_obj.datasources[i].uid != api_obj.current_selected_datasource.uid) {
                        // Add as Option
                        first_datasource = api_obj.datasources[i];
                        $("#relationship_meta_save_target_datasource").append('<option value="' + api_obj.datasources[i].uid + '">' + api_obj.datasources[i].name + '</option>');
                    }
                        
                }

                // Load Initial Datasource
                if(first_datasource)
                {
                    // Add all our columns
                    for(var i = 0; i < first_datasource.columns.length; i++) {

                        // Add as Option
                        $("#relationship_meta_save_target_column").append('<option value="' + first_datasource.columns[i].uid + '">' + first_datasource.columns[i].name + '</option>');
                        
                    }
                }

                // Stop Submit
                e.preventDefault();
                return false;

            });

            $("#relationship_meta_save_target_datasource").unbind();
            $("#relationship_meta_save_target_datasource").change(function(e){
            
                // Obj of Database
                var selected_database_to_add = api_obj.GetDatasourceInfoByUid($(this).val());

                if(selected_database_to_add) {

                    var columns = selected_database_to_add.datasource.columns;

                    // Clear
                    $("#relationship_meta_save_target_column").html('');

                    // Add all our columns
                    for(var i = 0; i < columns.length; i++) {

                        // Add as Option
                        $("#relationship_meta_save_target_column").append('<option value="' + columns[i].uid + '">' + columns[i].name + '</option>');
                        
                    }

                }

                // Stop Submit
                e.preventDefault();
                return false;

            });

            // Bind to Add Button for Relationship and Filters
            $("#meta_list_filters .meta_info_item_add_btn").click(function(e) {

                // Hide List
                $(".meta_side_block").hide();
                $("#relationship_meta_fields_add_filter").show();

                // Clear and Populate Inputs
                $("#relationship_meta_filter_save_column").html('');
                $("#relationship_meta_filter_save_type").html('');
                $("#relationship_meta_filter_save_expression").val('');

                // Add all our columns
                for(var i = 0; i < api_obj.current_selected_datasource.columns.length; i++) {

                    // Add as Option
                    $("#relationship_meta_filter_save_column").append('<option value="' + api_obj.current_selected_datasource.columns[i].uid + '">' + api_obj.current_selected_datasource.columns[i].name + '</option>');
                        
                }

                // Add our types
                for(var i = 0; i < api_obj.filter_types.length; i++) {

                    // Add as Option
                    $("#relationship_meta_filter_save_type").append('<option value="' + api_obj.filter_types[i].uid + '">' + api_obj.filter_types[i].name + '</option>');
                    
                }

                // Stop Submit
                e.preventDefault();
                return false;

            });

            // Hide Edit / Create Screens
            // Moved code to another button
            $(".relationship_meta_back_to_list").click();

            // Set the Sidebar Height
            manage_meta_sidebar_height();

            var current_post = 'left';
            var left_offset = 20, right_offset = 20;

            // Loop all the relationships
            for(var i = 0; i < api_obj.relationships.length; i++)
            {
                var offset = 0;
                var post = '';

                if(current_post == 'left')
                {
                    left_offset += 20;
                    offset = left_offset;
                    post = 'LeftMiddle';

                    current_post = 'right';
                } 
                else
                {
                    right_offset += 20;
                    offset = right_offset;
                    post = 'RightMiddle';

                    current_post = 'left';
                }

                jsPlumb.connect({
                    source: "preview_ds_" + api_obj.relationships[i].source.datasource,
                    target: "preview_ds_" + api_obj.relationships[i].target.datasource
                }, {
                    paintStyle: { lineWidth: 3, strokeStyle: "#056" },
                    endpoint: "Blank",
                    anchor: [post],
                    connector: ["Flowchart", { stub: [offset, offset], gap: 0}],
                    overlays: [["Label", {
                        cssClass: "relationship_preview_rel_line label",
                        label: '<a rel-id="' + api_obj.relationships[i].uid + '" href="javascript:void(0);"><img src="' + api_obj.config_path_to_remove_image + '" style="width:16px;"></a>',
                        location: 0.3
                    }]
                            ]
                });
            }

            // Bind to Window Resize

            // Remove Events from this Block
            $(".relationship_preview_rel_line a").unbind();
            $(".relationship_preview_rel_line a").bind('click', function () {

                if(api_obj.confirmDialog('Are you sure you want to remove this relationship?')) {

                    var rel_id = $(this).attr('rel-id');

                    rel_obj = _.find(api_obj.relationships, function(rel_obj) { return '' + rel_obj.uid == '' + rel_id; });
                    if(rel_obj)
                    {

                        // Remove
                        api_obj.removeRelationshipByUid(rel_id);
                        api_obj.removeDatasourceAndRelationship();

                    }

                }

                api_obj.render();

            });

            // SHow the Intro Block
            $("#info_relationship_preview_block").hide();

            // Hide the Preview Block
            $("#listing_relationship_preview_block").show();

        } else {

            // SHow the Intro Block
            $("#info_relationship_preview_block").show();

            // Hide the Preview Block
            $("#relationship_meta_fields").hide();
            $("#listing_relationship_preview_block").fadeOut('fast');

        }
        
    };

    /**
    * Returns the Summerized data for the Datasource
    * -> Datasource Object
    * -> Filters
    * -> Relationships
    **/
    api_obj.GetDatasourceInfoByUid = function(datasource_uid) {

        // Get the Datasource Obj
        var datasource_obj = _.find(this.datasources, function(db_obj) { return db_obj.uid == datasource_uid; });

        if(datasource_obj)
        {

            return {
                'datasource': datasource_obj,
                'filters': _.filter(this.filters, function(filter_obj){ return filter_obj.datasource == datasource_uid; }),
                'relationships': _.filter(this.relationships, function(rel_obj){ return rel_obj.source.datasource == datasource_uid || rel_obj.target.datasource == datasource_uid; })
            };

        } else return false;

    };

    /**
    * Returns Values used to save.
    *
    * This object contains all the datasources,relationships and filters created
    **/
    api_obj.getSaveData = function() {

        // Save Object to Return
        var save_obj = {};

        // Get Grouped Values
        save_obj.relationships = _.groupBy(this.relationships, function(rel_obj){ return rel_obj.source.datasource; });
        save_obj.filters = _.groupBy(this.filters, function(rel_obj){ return rel_obj.source.datasource; });
        save_obj.datasources = _.pluck(this.datasources,'uid');

        // Return !
        return save_obj;

    };

    // Set as Var
    RelationshipMapper = relationshipMapper = api_obj;

    // Set the Height of the Meta Sidebar
    var manage_meta_sidebar_height = function(){
    
        // Set the Height of the SIdebar Slider
        var wrapper_height = $('#relationship_mapper_block').height();
        var meta_title_height = $("#relationship_meta_fields_title").height();

        var meta_section_height = 0;
        $(".meta_info_section_title").each(function() {

            meta_section_height = meta_section_height + ($(this).height() || 0);

        });

        var meta_buttons_height = 50;
        var dividing = $(".meta_info_section_body").size();

        // Set the Meta Sidebar Widget
        var meta_sidebar_content_height = (wrapper_height - (meta_buttons_height + meta_section_height + meta_section_height)) / dividing;

        // Set the Content Height
        $(".meta_info_section_body").height(meta_sidebar_content_height);

    };

    // Bind to Window
    var update_func = _.throttle(function(){
        
        // Render our Arrows
        api_obj.render();

        // Change Sidebar Height
        manage_meta_sidebar_height();
    
    }, 50);
    $(window).resize(update_func);

})(jQuery);