﻿Type.registerNamespace("Amakozi.Reporting.Tridion.Editor.Views");

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource = function InsertDatasource()
{
    Tridion.OO.enableInterface(this, "Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource");
    this.addInterface("Tridion.Cme.View");
    this.properties.DATASOURCE_HEAD_PATH = $config.expandEditorPath("/Xml/ListDefinitions/BasicDropdownListHead.xml");
    this.properties.COLUMN_HEAD_PATH = $config.expandEditorPath("/Xml/ListDefinitions/ColumnsDropdownListHead.xml");
    this.properties.datasourceDropdownHeadXml = null;
    this.properties.columnDropdownHeadXml = null;
    this.properties.isDropdownHeadLoaded = false;
    this.properties.targetDatasourceBodyXml = null;
};

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.initialize = function InsertDatasource$initialize()
{
    this.callBase("Tridion.Cme.View", "initialize");
    var p = this.properties;
    var c = p.controls;
    p.params = window.dialogArguments || {};

    $controls.getControl($("#StackElement"), "Tridion.Controls.Stack");
    $controls.getControl($("#MessageCenter"), "Tridion.Controls.ActiveMessageCenter");

    c.CloseButton = $controls.getControl($("#CloseButton"), "Tridion.Controls.Button");
    c.ApplyButton = $controls.getControl($("#ApplyButton"), "Tridion.Controls.Button");

    c.SourceDatasource = $controls.getControl($("#SourceDatasource"), "Tridion.Controls.Dropdown");
    c.SourceColumn = $controls.getControl($("#SourceColumn"), "Tridion.Controls.Dropdown");
    c.TargetDatasource = $controls.getControl($("#TargetDatasource"), "Tridion.Controls.Dropdown");
    c.TargetColumn = $controls.getControl($("#TargetColumn"), "Tridion.Controls.Dropdown");

    $evt.addEventHandler(c.SourceDatasource, "loadcontent", this.getDelegate(this.onSourceDatasourceLoadContent));
    $evt.addEventHandler(c.SourceDatasource, "change", this.getDelegate(this.onSourceDatasourceValueChanged));
    $evt.addEventHandler(c.SourceColumn, "contentloaded", this.getDelegate(this.onSourceColumnContentLoaded));
    $evt.addEventHandler(c.TargetDatasource, "change", this.getDelegate(this.onTargetDatasourceValueChanged));
    $evt.addEventHandler(c.TargetDatasource, "contentloaded", this.getDelegate(this.onTargetDatasourceContentLoaded));
    $evt.addEventHandler(c.TargetColumn, "contentloaded", this.getDelegate(this.onTargetColumnContentLoaded));

    $evt.addEventHandler(c.ApplyButton, "click", this.getDelegate(this._onApplyBtnClicked));
    $evt.addEventHandler(c.CloseButton, "click", this.getDelegate(this._onCloseBtnClicked));

    p.targetDatasourceBodyXml = p.params.targetDatasourceList;
    this.initializeControls();
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.initializeControls = function InsertDatasource$initializeControls()
{
    var p = this.properties;
    var c = p.controls;
    if (p.isDropdownHeadLoaded)
    {
        c.SourceDatasource.reset();
        c.SourceColumn.reset();
        c.TargetDatasource.reset();
        c.TargetColumn.reset();
        c.TargetDatasource.disable();
        if (p.targetDatasourceBodyXml)
        {
            c.TargetDatasource.setContent(p.targetDatasourceBodyXml, $xml.getOuterXml(p.datasourceDropdownHeadXml));
        }
        c.SourceColumn.disable();
        c.TargetColumn.disable();

    } else
    {
        this.loadDropdownHead();
    }
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onSourceDatasourceValueChanged = function InsertDatasource$onSourceDatasourceValueChanged()
{
    var p = this.properties;
    var c = p.controls;
    c.SourceColumn.reset();
    c.SourceColumn.disable();
    this.SourceColumnLoadContent();
};

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.SourceColumnLoadContent = function InsertDatasource$SourceColumnLoadContent()
{
    var p = this.properties;
    var c = p.controls;

    var sourceColumnListLoaded = function (columnsXml)
    {
        c.SourceColumn.setContent(columnsXml, $xml.getOuterXml(p.columnDropdownHeadXml));
    }
    Amakozi.Reporting.Tridion.Model.AmakoziReportingService.GetSystemList("datasourcecolumns", c.SourceDatasource.getValue(), sourceColumnListLoaded)
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onSourceColumnContentLoaded = function InsertDatasource$onSourceColumnContentLoaded()
{
    this.properties.controls.SourceColumn.enable();
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onTargetDatasourceValueChanged = function InsertDatasource$onTargetDatasourceValueChanged()
{
    var p = this.properties;
    var c = p.controls;
    c.TargetColumn.reset();
    c.TargetColumn.disable();
    this.TargetColumnLoadContent();
};

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.TargetColumnLoadContent = function InsertDatasource$TargetColumnLoadContent()
{
    var p = this.properties;
    var c = p.controls;

    var targetColumnListLoaded = function (columnsXml)
    {
        c.TargetColumn.setContent(columnsXml, $xml.getOuterXml(p.columnDropdownHeadXml));
    }
    Amakozi.Reporting.Tridion.Model.AmakoziReportingService.GetSystemList("datasourcecolumns", c.TargetDatasource.getValue(), targetColumnListLoaded)
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onTargetColumnContentLoaded = function InsertDatasource$onTargetColumnContentLoaded()
{
    this.properties.controls.TargetColumn.enable();
}
Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onTargetDatasourceContentLoaded = function InsertDatasource$onTargetDatasourceContentLoaded()
{
    this.properties.controls.TargetDatasource.enable();
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onSourceDatasourceLoadContent = function Datasource$onSourceDatasourceLoadContent()
{
    var p = this.properties;
    var c = p.controls;
    var sourceDSList = $models.getItem($const.TCMROOT).getList(new Tridion.ContentManager.ListFilter(), undefined, undefined, "Amakozi.Reporting.Tridion.Model.DatasourceList");

    var SourceDSListLoaded = function ()
    {
        $evt.removeEventHandler(sourceDSList, "load", SourceDSListLoaded);
        c.SourceDatasource.setContent(sourceDSList.getXml(), $xml.getOuterXml(p.datasourceDropdownHeadXml));
    }

    if (sourceDSList.isLoaded(true))
    {
        SourceDSListLoaded();
    } else
    {
        $evt.addEventHandler(sourceDSList, "load", SourceDSListLoaded);
        sourceDSList.load();
    }
};


Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype._onCloseBtnClicked = function InsertDatasource$_onCloseBtnClicked(event)
{
    window.close();
};

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype._onApplyBtnClicked = function InsertDatasource$_onApplyBtnClicked(event)
{
    var p = this.properties;
    var c = p.controls;
    if(this.validate())
    {
        this.fireEvent("apply", this.getData());
        window.close();
    }
};

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.validate = function InsertDatasource$validate()
{
    var p = this.properties;
    var c = p.controls;
    var error = null;
    if (c.SourceDatasource.getValue() == null)
    {
        error = $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "PleaseSelect", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "SourceDatasource")])
    }
    if (!error)
    {
        if (!c.TargetDatasource.isDisabled())
        {
            if (c.TargetDatasource.getValue() == null)
            {
                error = $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "PleaseSelect", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "TargetDatasource")])
            } else
            {
                if (c.SourceColumn.getValue() == null)
                {
                    error = $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "PleaseSelect", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "SourceJoiningColumn")])
                } else
                {
                    if (c.TargetColumn.getValue() == null)
                    {
                        error = $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "PleaseSelect", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "TargetJoiningColumn")])
                    }
                }
            }
        }
    }
    if (error)
    {
        $messages.registerError(error, null, null, true, true);
        return false;
    }
    return true;
}
Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.getData = function InsertDatasource$getData()
{
    var p = this.properties;
    var c = p.controls;
    var columns = [];
    var columnNodes = $xml.selectNodes(c.SourceColumn.getContent(), "//tcm:Column", $const.Namespaces);
    for (var i = 0; i < columnNodes.length; i++)
    {
        columns.push({ uid: columnNodes[i].getAttribute("id"), name: columnNodes[i].getAttribute("name") });
    }
    var data = {
        sourceDatasourceId: this.cleanId(c.SourceDatasource.getValue()),
        sourceDatasourceTitle: c.SourceDatasource.getTitle(),
        sourceColumnCollection: columns
    }
    if(c.TargetDatasource.getValue() !== null){
        data.relationship =
        { source_datasource_uid: this.cleanId(c.SourceDatasource.getValue()),
            target_datasource_uid: this.cleanId(c.TargetDatasource.getValue()),
            source_column: c.SourceColumn.getValue(),
            target_column: c.TargetColumn.getValue(),
            join_type: "INNER",
            priority: 1
        }
    }
    return data;
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.cleanId = function InsertDatasource$getData(id)
{
    if (Type.isString(id) && isNaN(Number(id)))
    {
        return id.split(":")[1].split("-")[0];
    }
    return id;
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.onDropdownHeadLoaded = function InsertDatasource$onDropdownHeadLoaded(xml)
{
    this.properties.columnDropdownHeadXml = xml;
    this.properties.isDropdownHeadLoaded = true;
    this.initializeControls();
}

Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource.prototype.loadDropdownHead = function InsertDatasource$loadDropdownHead()
{
    if (!this.properties.isDropdownHeadLoaded)
    {
        var self = this;
        var LoadColumnsHead = function (xml)
        {
            self.properties.datasourceDropdownHeadXml = xml;
            $xml.loadXmlDocument(self.properties.COLUMN_HEAD_PATH, self.getDelegate(self.onDropdownHeadLoaded));
        }
        $xml.loadXmlDocument(this.properties.DATASOURCE_HEAD_PATH, LoadColumnsHead);
    }
}

$display.registerView(Amakozi.Reporting.Tridion.Editor.Views.InsertDatasource);