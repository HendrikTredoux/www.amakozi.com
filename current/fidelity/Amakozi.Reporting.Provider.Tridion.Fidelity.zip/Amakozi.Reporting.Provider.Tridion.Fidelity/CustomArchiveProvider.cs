﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using Amakozi.Reporting.Tridion.Archive;
using Amakozi.Reporting.Tridion.Archive.Filters;
using Amakozi.Reporting.Provider.Data;
using Tridion.ContentManager.CoreService.Client;
using Amakozi.Reporting.Tridion.Archive.Logging;

namespace Amakozi.Reporting.Provider.Tridion.Fidelity
{
    [Serializable]
    [Provider.Data.DataProviderColumn(Name = "Item URI", Uid = "col_tcma_uri", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Item URI Anchor", Uid = "col_tcma_uri_url", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Item ID", Uid = "col_tcma_item_id", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Item Type", Uid = "col_tcma_type", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Publication ID", Uid = "col_tcma_publication", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Localized", Uid = "col_tcma_localized", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Creator", Uid = "col_tcma_creator", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Created Date", Uid = "col_tcma_created_date", Type = ColumnType.DATETIME)]
    [Provider.Data.DataProviderColumn(Name = "Current Version", Uid = "col_tcma_current_version", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Title", Uid = "col_tcma_title", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Revisor", Uid = "col_tcma_revisor", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Version", Uid = "col_tcma_version", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Revision Date", Uid = "col_tcma_revision_date", Type = ColumnType.DATETIME)]
    [Provider.Data.DataProviderColumn(Name = "Deleted", Uid = "col_tcma_is_deleted", Type = ColumnType.NUMBER)]
    [Provider.Data.DataProviderColumn(Name = "Deleted Date", Uid = "col_tcma_deleted_date", Type = ColumnType.DATETIME)]
    [Provider.Data.DataProviderColumn(Name = "Deleted By", Uid = "col_tcma_deleted_by", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "OrgItem URI", Uid = "col_tcma_orgitem_uri", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Content Field1", Uid = "col_tcma_content1", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Content Field2", Uid = "col_tcma_content2", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Content Field3", Uid = "col_tcma_content3", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Used By", Uid = "col_tcma_where_uri", Type = ColumnType.TEXT)]
    [Provider.Data.DataProviderColumn(Name = "Used Title", Uid = "col_tcma_where_title", Type = ColumnType.TEXT)]

    [Provider.Data.DataProviderInput(Seed = 11, Name = "EReview Number", Uid = "tia_review_number", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 12, Name = "EReview DOFU Min", Uid = "tia_dofu_min", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 13, Name = "EReview DOFU Max", Uid = "tia_dofu_max", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 14, Name = "EReview EXPR Min", Uid = "tia_expr_min", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 15, Name = "EReview EXPR Max", Uid = "tia_expr_max", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 16, Name = "Display Start Min", Uid = "tia_displaystart_min", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 17, Name = "Display Start Max", Uid = "tia_displaystart_max", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 18, Name = "Display End Min", Uid = "tia_displayend_min", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 19, Name = "Display End Max", Uid = "tia_displayend_max", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 20, Name = "Topic", Uid = "tia_topic", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]

    [Provider.Data.DataProviderInput(Seed = 41, Name = "ItemType", Uid = "tia_item_type", Type = InputType.NUMBER, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 42, Name = "Publication ID", Uid = "tia_publication_id", Type = InputType.NUMBER, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 43, Name = "Schema ID", Uid = "tia_schema_id", Type = InputType.NUMBER, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 44, Name = "Created Date Range Start", Uid = "tia_c_start_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 45, Name = "Created Date Range End", Uid = "tia_c_end_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 46, Name = "Revision Date Range Start", Uid = "tia_r_start_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 47, Name = "Revision Date Range End", Uid = "tia_r_end_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 48, Name = "Content Manager Url", Uid = "tia_anchor_url", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 49, Name = "Deleted State", Uid = "tia_deleted", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL, MultiSelect = new String[] { "any|Any", "deleted|Deleted", "existing|Existing" })]
    [Provider.Data.DataProviderInput(Seed = 50, Name = "Deleted Date Range Start", Uid = "tia_deleted_start_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 51, Name = "Deleted Date Range End", Uid = "tia_deleted_end_date", Type = InputType.DATETIME, Required = InputRequiredLevel.OPTIONAL, AllowExpressionBuilder = true)]
    [Provider.Data.DataProviderInput(Seed = 52, Name = "Return", Uid = "tia_return_type", Type = InputType.TEXT, Required = InputRequiredLevel.Report, MultiSelect = new String[] { "all_items|All Items", "old_items|Archived Items", "new_items|Fresh / Current Items" })]
    [Provider.Data.DataProviderInput(Seed = 52, Name = "Localized", Uid = "tia_localized", Type = InputType.TEXT, Required = InputRequiredLevel.Report, MultiSelect = new String[] { "all_items|All Items", "localized|Localized", "notlocalized|Not Localized" })]
    [Provider.Data.DataProviderInput(Seed = 53, Name = "Content Field1 XPath", Uid = "tia_content_field1", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 54, Name = "Content Field2 XPath", Uid = "tia_content_field2", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 55, Name = "Content Field3 XPath", Uid = "tia_content_field3", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 70, Name = "Include Where Used", Uid = "tia_whereused", Type = InputType.YESNO, Required = InputRequiredLevel.Report)]
    [Provider.Data.DataProviderInput(Seed = 71, Name = "Tridion Host", Uid = "tr_host", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 72, Name = "Tridion User", Uid = "tr_user", Type = InputType.TEXT, Required = InputRequiredLevel.OPTIONAL)]
    [Provider.Data.DataProviderInput(Seed = 73, Name = "Tridion Password", Uid = "tr_password", Type = InputType.PASSWORD, Required = InputRequiredLevel.OPTIONAL)]

    [Provider.Data.DataProviderInfo(Name = "Fidelity Tridion Archive Items", Author = "Amakozi Technologies CC", Website = "http://www.amakozi.com/", Version = "0.0.1", Description = "Returns Archived Items from the Reporting Archive Event System")]
    class TridionItemArchive : Provider.Data.DataProviderBase
    {

        public void Excute(DataRequest request)
        {
            //filter for archive data query
            var filter = new ArchiveItemFilter();

            //check if input exists and if nullable int has a value
            if (request.Parameters.CheckInput("tia_item_type") && request.Parameters.GetInt("tia_item_type").HasValue)
            {
                filter.ItemType = request.Parameters.GetInt("tia_item_type").Value;
            }
            if (request.Parameters.CheckInput("tia_publication_id") && request.Parameters.GetInt("tia_publication_id").HasValue)
            {
                filter.PublicationId = request.Parameters.GetInt("tia_publication_id").Value;
            }
            if (request.Parameters.CheckInput("tia_schema_id") && request.Parameters.GetInt("tia_schema_id").HasValue)
            {
                filter.SchemaId = request.Parameters.GetInt("tia_schema_id").Value;
            }

            //use daterange object for start/end date scenarios where to inputs are query paramaters for a single date field in the archive data
            filter.CreatedDateRange = new DateRange();
            filter.DeletedDateRange = new DateRange();
            filter.RevisionDateRange = new DateRange();

            // Start and End date to filter by
            if (request.Parameters.CheckInput("tia_c_start_date") && request.Parameters.GetDateTime("tia_c_start_date").HasValue)
            {
                filter.CreatedDateRange.SetStartDate(request.Parameters.GetDateTime("tia_c_start_date").Value);
            }
            if (request.Parameters.CheckInput("tia_c_end_date") && request.Parameters.GetDateTime("tia_c_end_date").HasValue)
            {
                filter.CreatedDateRange.SetEndDate(request.Parameters.GetDateTime("tia_c_end_date").Value);
            }
            if (request.Parameters.CheckInput("tia_r_start_date") && request.Parameters.GetDateTime("tia_r_start_date").HasValue)
            {
                filter.RevisionDateRange.SetStartDate(request.Parameters.GetDateTime("tia_r_start_date").Value);
            }
            if (request.Parameters.CheckInput("tia_r_end_date") && request.Parameters.GetDateTime("tia_r_end_date").HasValue)
            {
                filter.RevisionDateRange.SetEndDate(request.Parameters.GetDateTime("tia_r_end_date").Value);
            }
            filter.Versions = request.Parameters.GetString("tia_return_type", "all_items");
            
            filter.LocalizedState = request.Parameters.GetString("tia_localized", "all_items");

            //deleted date values are only considered if filtering for deleted items
            switch (request.Parameters.GetString("tia_deleted", string.Empty))
            {
                case "deleted":
                    filter.DeletedSate = "deleted";
                    if (request.Parameters.CheckInput("tia_deleted_start_date") && request.Parameters.GetDateTime("tia_deleted_start_date").HasValue)
                    {
                        filter.DeletedDateRange.SetStartDate(request.Parameters.GetDateTime("tia_deleted_start_date").Value);
                    }
                    if (request.Parameters.CheckInput("tia_deleted_end_date") && request.Parameters.GetDateTime("tia_deleted_end_date").HasValue)
                    {
                        filter.DeletedDateRange.SetEndDate(request.Parameters.GetDateTime("tia_deleted_end_date").Value);
                    }
                    break;
                case "existing":
                    filter.DeletedSate = "existing";
                    break;
            }

            //is this a number or a string?
            if (request.Parameters.CheckInput("tia_review_number"))
            {
                ArchiveItemFilter.MetadataCondition metaDataCondition = new ArchiveItemFilter.MetadataCondition()
                {
                    BasicFieldType = ArchiveItemFilter.MetadataCondition.FieldType.TEXT,
                    ComparisonOperator = ArchiveItemFilter.MetadataCondition.ComparisonType.EQUALS,
                    FieldValue = request.Parameters.GetString("tia_review_number")
                };
                metaDataCondition.FieldName.Add("//componentMetadata/eReview/componentEreviewNum");
                metaDataCondition.FieldName.Add("//pgeReview/pageEreviewNum");                    
                filter.MetdataConditions.Add(metaDataCondition);
            }

            if (request.Parameters.CheckInput("tia_topic"))
            {
                ArchiveItemFilter.MetadataCondition metaDataCondition = new ArchiveItemFilter.MetadataCondition()
                {
                    BasicFieldType = ArchiveItemFilter.MetadataCondition.FieldType.TEXT,
                    ComparisonOperator = ArchiveItemFilter.MetadataCondition.ComparisonType.EQUALS,
                    FieldValue = request.Parameters.GetString("tia_topic")
                };
                metaDataCondition.FieldName.Add("//componentMetadata/componentDetail/VSTOPIC");
                filter.MetdataConditions.Add(metaDataCondition);
            }

            var metadataExprDateCondition = new ArchiveItemFilter.MetadataCondition();
            if(ConfigureMetaDateRange(request, new String[]{"//componentMetadata/eReview/componentEXPR"}, "tia_expr_min", "tia_expr_max", metadataExprDateCondition))
            {
                filter.MetdataConditions.Add(metadataExprDateCondition);
            }

            //tia_dofu_min
            //tia_dofu_max
            var metadataDofuDateCondition = new ArchiveItemFilter.MetadataCondition();
            if(ConfigureMetaDateRange(request, new String[]{"//componentMetadata/eReview/componentDOFU"}, "tia_dofu_min", "tia_dofu_max", metadataDofuDateCondition))
            {
                filter.MetdataConditions.Add(metadataDofuDateCondition);
            }

            //tia_displaystart_min
            //tia_displaystart_max
            var metadataDisplayStartDateCondition = new ArchiveItemFilter.MetadataCondition();
            if(ConfigureMetaDateRange(request, new String[]{"//componentMetadata/core/componentStartDate", "//pgCore/pageStartDate"}, "tia_displaystart_min", "tia_displaystart_max", metadataDisplayStartDateCondition))
            {
                filter.MetdataConditions.Add(metadataDisplayStartDateCondition);
            }

            //tia_displayend_min
            //tia_displayend_max
            var metadataDisplayEndDateCondition = new ArchiveItemFilter.MetadataCondition();
            if (ConfigureMetaDateRange(request, new String[]{"//componentMetadata/core/componentEndDate", "//pgCore/pageEndDate"}, "tia_displayend_min", "tia_displayend_max", metadataDisplayEndDateCondition))
            {
                filter.MetdataConditions.Add(metadataDisplayEndDateCondition);
            }

            bool includeWhereUsed = false;
            if (request.Parameters.CheckInput("tia_whereused"))
            {
                includeWhereUsed = request.Parameters.GetBool("tia_whereused", false);
            }

            //declare coreservice session variable here to allow for proper disposing later
            CoreServiceSession session = null;
            XNamespace ns = "http://www.tridion.com/ContentManager/5.0";
            try
            {
                if (includeWhereUsed)
                {
                    if (request.Parameters.CheckInput("tr_host") && request.Parameters.CheckInput("tr_user") && request.Parameters.CheckInput("tr_password"))
                    {
                        session = new CoreServiceSession(request.Parameters.GetString("tr_host"), request.Parameters.GetString("tr_user"), request.Parameters.GetString("tr_password"));
                    }
                    else
                    {
                        throw new ProviderException("Complete Tridion credential details to use 'where used' info");
                    }
                }
                foreach (var item in Amakozi.Reporting.Tridion.Archive.Data.GetItems(filter, request.RowLimit))
                {
                    XElement xUsed = null;
                    if (includeWhereUsed)
                    {
                        UsedItemsFilterData usedItemsFilter = new UsedItemsFilterData()
                        {
                            BaseColumns = ListBaseColumns.IdAndTitle,
                            ItemTypes = new ItemType[] { ItemType.Component, ItemType.Page },
                        };
                        xUsed = session.ServiceClient.GetListXml(item.TcmUri, usedItemsFilter);
                        foreach (var xItem in xUsed.Descendants(ns + "Item"))
                        {
                            SetResultRow(request, item, xItem.Attribute("ID").Value, xItem.Attribute("Title").Value);
                        }
                    }
                    else
                    {
                        SetResultRow(request, item, null, null);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ProviderException("Fidelity Tridion Archive Provider: " + ex.Message);
            }
            finally
            {
                if (session != null)
                {
                    session.Dispose();
                }
            }
        }

        private void SetResultRow(DataRequest request, ArchiveItem item, string whereUsedUri, string whereUsedTitle)
        {
            request.setColumn("col_tcma_uri_url", "<a href=\"" + request.Parameters.GetString("tia_anchor_url", "") + "/WebUI/item.aspx?tcm=" + item.ItemType + "#id=tcm:" + item.PublicationId + "-" + item.ItemId + "-" + item.ItemType + " \" target=\"_blank\">tcm:" + item.PublicationId + "-" + item.ItemId + "-" + item.ItemType + "</a>");
            request.setColumn("col_tcma_uri", "tcm:" + item.PublicationId + "-" + item.ItemId + "-" + item.ItemType);
            request.setColumn("col_tcma_publication", item.PublicationId);
            request.setColumn("col_tcma_item_id", item.ItemId);
            request.setColumn("col_tcma_type", item.ItemType);
            request.setColumn("col_tcma_where_uri", whereUsedUri ?? string.Empty);
            request.setColumn("col_tcma_where_title", whereUsedTitle ?? string.Empty);
            request.setColumn("col_tcma_localized", item.IsLocalized);
            request.setColumn("col_tcma_creator", item.Creator);
            request.setColumn("col_tcma_created_date", (object)item.CreatedDate);
            request.setColumn("col_tcma_current_version", item.CurrentVersion);
            request.setColumn("col_tcma_title", item.Title);
            request.setColumn("col_tcma_revisor", item.Revisor);
            request.setColumn("col_tcma_version", item.Version);
            request.setColumn("col_tcma_revision_date", (object)item.RevisionDate);
            request.setColumn("col_tcma_is_deleted", item.IsDeleted);
            if (item.IsDeleted)
            {
                request.setColumn("col_tcma_deleted_date", (object)item.DeletedDate);
                request.setColumn("col_tcma_deleted_by", item.DeletedBy);
            }

            if (item.ItemType == 64 || item.ItemType == 4)
            {
                request.setColumn("col_tcma_orgitem_uri", "tcm:" + item.PublicationId + "-" + item.OrgItemId + "-4");
            }
            else
            {
                request.setColumn("col_tcma_orgitem_uri", "tcm:" + item.PublicationId + "-" + item.OrgItemId + "-2");
            }
            foreach (var metaItem in item.Meta)
            {
                request.setColumn(metaItem.Field, metaItem.Value);
            }

            if (!string.IsNullOrWhiteSpace(item.Content))
            {
                XmlDocument contentDoc = null;
                try
                {
                    XmlNamespaceManager nsm = null;
                    for (int i = 1; i < 4; i++)
                    {
                        string xpath = request.Parameters.GetString("tia_content_field" + i);
                        if (!string.IsNullOrWhiteSpace(xpath))
                        {
                            if (contentDoc == null)
                            {
                                contentDoc = new XmlDocument();
                                contentDoc.LoadXml(item.Content);
                                nsm = new XmlNamespaceManager(contentDoc.NameTable);
                                nsm.AddNamespace("tcm", contentDoc.DocumentElement.NamespaceURI);
                            }
                            var node = contentDoc.SelectSingleNode(Amakozi.Reporting.Tridion.Archive.ArchiveItem.ValidCleanXPath(xpath), nsm);
                            if (node != null)
                            {
                                request.setColumn("col_tcma_content" + i, node.InnerText);
                            }
                        }
                    }
                }
                catch { }
                finally
                {
                    contentDoc = null;
                }
            }
            request.Send();
        }

        private bool ConfigureMetaDateRange(DataRequest request, string[] fieldName, string inputNameStartDate, string inputNameEndDate, ArchiveItemFilter.MetadataCondition condition)
        {
            DateRange daterange = new DateRange();
            condition.FieldName.AddRange(fieldName);
            condition.BasicFieldType = ArchiveItemFilter.MetadataCondition.FieldType.DATETIME;
            if (request.Parameters.CheckInput(inputNameStartDate))
            {
                condition.ComparisonOperator = ArchiveItemFilter.MetadataCondition.ComparisonType.GREATER_THAN_OR_EQUAL;
                daterange.SetStartDate(request.Parameters.GetDateTime(inputNameStartDate, DateTime.MinValue));
            }
            if (request.Parameters.CheckInput(inputNameEndDate))
            {
                condition.ComparisonOperator = ArchiveItemFilter.MetadataCondition.ComparisonType.LESS_THAN_OR_EQUAL;
                daterange.SetEndDate(request.Parameters.GetDateTime(inputNameEndDate, DateTime.MaxValue));
            }
            condition.FieldValue = daterange;
            return (daterange.StartIsSet || daterange.EndIsSet);
        }
    }
}
