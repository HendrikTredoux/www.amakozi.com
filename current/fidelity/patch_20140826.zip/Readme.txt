- Patch for multiple metadata schemas with the same field definitions.
- Patch to allow one input to be a parameter for multiple field definitions.
- Fidelity custom provider update for specific page metadata field names.
- Fidelity custom provider update to map one parameter to multiple field definitions.

Deployment:

Stop the "SDL Tridon Content Manager" com+ application
Stop the "Amakozi Reporting Service" windows service
Stop the "Tridion Services Host" windows service

Copy Amakozi.Reporting.Tridion.Archive.dll to the following locations:

<Reporting Install>/Core/Providers/Data

<TridionHome>/bin


Copy Amakozi.Reporting.Provider.Tridion.Fidelity.dll to the following location:

<Reporting Install>/Core/Providers/Data


Copy Amakozi.Reporting.Core.dll to the following location:

<Reporting Install>/Core


Restart services


