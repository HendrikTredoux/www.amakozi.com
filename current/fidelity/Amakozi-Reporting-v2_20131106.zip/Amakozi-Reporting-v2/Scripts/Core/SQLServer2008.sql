USE [Reporting]
GO
/****** Object:  Table [dbo].[sections]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[sections](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[report] [int] NOT NULL,
	[title] [varchar](255) NULL,
	[type] [int] NOT NULL,
	[reportdefinition] [int] NOT NULL,
	[template_section] [varchar](255) NOT NULL,
	[chart_type] [int] NULL,
	[x_axis] [varchar](255) NULL,
	[y_axis] [varchar](255) NULL,
	[legends] [text] NULL,
	[series] [text] NULL,
	[group_by] [varchar](255) NULL,
	[limit] [int] NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_sections] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[roles]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[roles](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[permissions] [text] NOT NULL,
	[role] [int] NOT NULL,
	[trustee] [varchar](100) NOT NULL,
	[target] [varchar](100) NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_roles] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[reports]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[reports](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[template_uid] [varchar](255) NULL,
	[template_layout] [varchar](255) NULL,
	[created_by] [varchar](255) NOT NULL,
	[created] [date] NOT NULL,
	[lastupdated] [date] NOT NULL,
 CONSTRAINT [PK_reports] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[reportdefinitions]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[reportdefinitions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[querydefinition] [int] NOT NULL,
	[created_by] [varchar](255) NOT NULL,
	[created] [date] NOT NULL,
	[lastupdated] [date] NOT NULL,
 CONSTRAINT [PK_reportdefinitions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[relationships]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[relationships](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[querydefinition] [int] NOT NULL,
	[source_datasource] [int] NOT NULL,
	[source_column] [varchar](255) NOT NULL,
	[destination_datasource] [int] NOT NULL,
	[destination_column] [varchar](255) NOT NULL,
	[case_matter] [int] NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_relationships] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[querydefinitions]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[querydefinitions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[datasources] [text] NOT NULL,
	[created_by] [varchar](255) NOT NULL,
	[created] [date] NOT NULL,
	[lastupdated] [date] NOT NULL,
 CONSTRAINT [PK_querydefinitions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[jobs]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[jobs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[cron_string] [varchar](50) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[destination_provider] [varchar](255) NULL,
	[format_provider] [varchar](255) NULL,
	[target] [varchar](255) NOT NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_jobs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[inputs]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[inputs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[datasource] [varchar](100) NULL,
	[target] [varchar](100) NOT NULL,
	[height] [int] NOT NULL,
	[provider] [varchar](100) NOT NULL,
	[value] [text] NOT NULL,
	[name] [varchar](100) NOT NULL,
	[created] [datetime] NOT NULL,
 CONSTRAINT [PK_inputs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[filters]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[filters](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[querydefinition] [int] NOT NULL,
	[column_uid] [varchar](255) NULL,
	[datasource] [varchar](255) NOT NULL,
	[type] [int] NOT NULL,
	[value] [varchar](255) NOT NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_filters] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[datasources]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[datasources](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NOT NULL,
	[created_by] [varchar](255) NOT NULL,
	[provider] [varchar](255) NOT NULL,
	[cache] [tinyint] NOT NULL,
	[cache_duration] [int] NULL,
	[created] [date] NOT NULL,
	[lastupdated] [date] NOT NULL,
 CONSTRAINT [PK_datasources] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[columns]    Script Date: 03/08/2013 12:43:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[columns](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[report] [int] NULL,
	[section] [int] NULL,
	[reportdefinition] [int] NULL,
	[seed] [int] NULL,
	[datasource] [varchar](255) NULL,
	[provider] [varchar](255) NULL,
	[column_uid] [varchar](255) NOT NULL,
	[sorting] [int] NOT NULL,
	[direction] [int] NULL,
	[title] [varchar](255) NULL,
	[created] [datetime] NOT NULL,
	[lastupdated] [datetime] NOT NULL,
 CONSTRAINT [PK_columns] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Default [DF_columns_seed]    Script Date: 03/08/2013 12:43:17 ******/
ALTER TABLE [dbo].[columns] ADD  CONSTRAINT [DF_columns_seed]  DEFAULT ((0)) FOR [seed]
GO
/****** Object:  Default [DF_columns_sorting]    Script Date: 03/08/2013 12:43:17 ******/
ALTER TABLE [dbo].[columns] ADD  CONSTRAINT [DF_columns_sorting]  DEFAULT ((0)) FOR [sorting]
GO
/****** Object:  Default [DF_datasources_cache]    Script Date: 03/08/2013 12:43:17 ******/
ALTER TABLE [dbo].[datasources] ADD  CONSTRAINT [DF_datasources_cache]  DEFAULT ((0)) FOR [cache]
GO
/****** Object:  Default [DF_relationships_case_matter]    Script Date: 03/08/2013 12:43:17 ******/
ALTER TABLE [dbo].[relationships] ADD  CONSTRAINT [DF_relationships_case_matter]  DEFAULT ((0)) FOR [case_matter]
GO
