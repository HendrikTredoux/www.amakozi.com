﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Amakozi.Reporting.Provider.Data;
using Amakozi.Reporting.Provider.Utils;

namespace Amakozi.Reporting.Provider.Data.SQL
{
    [Serializable]
    [DataProviderInfo(Name = "SQL", Description = "SQL Query", Version = "0.0.1", Website = "http://www.amakozi.com", Author = "Amakozi Technologies CC")]

    [DataProviderInput(Seed = 1, Name = "Server", Description = "Server", Uid = "sql_server", Required = InputRequiredLevel.Datasource, Type = InputType.TEXT)]
    [DataProviderInput(Seed = 2, Name = "Provider", Description = "Database Provider/Driver", Uid = "sql_provider", Required = InputRequiredLevel.Datasource, Type = InputType.TEXT)]
    [DataProviderInput(Seed = 4, Name = "Database", Description = "Database", Uid = "sql_database", Required = InputRequiredLevel.Datasource, Type = InputType.TEXT)]
    [DataProviderInput(Seed = 3, Name = "Port", Description = "Port", Uid = "sql_port", Required = InputRequiredLevel.OPTIONAL, Type = InputType.TEXT)]
    [DataProviderInput(Seed = 5, Name = "Username", Description = "Username", Uid = "sql_username", Required = InputRequiredLevel.Datasource, Type = InputType.TEXT)]
    [DataProviderInput(Seed = 6, Name = "Password", Description = "Password", Uid = "sql_password", Required = InputRequiredLevel.Datasource, Type = InputType.PASSWORD)]
    [DataProviderInput(Seed = 7, Name = "SQL Query", Description = "SQL Query", Uid = "sql_query", Required = InputRequiredLevel.Datasource, Type = InputType.TEXT, AllowExpressionBuilder = true)]

    [DataProviderColumn(Uid = "sql_col1", Name = "Column 1", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col2", Name = "Column 2", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col3", Name = "Column 3", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col4", Name = "Column 4", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col5", Name = "Column 5", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col6", Name = "Column 6", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col7", Name = "Column 7", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col8", Name = "Column 8", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col9", Name = "Column 9", Type = ColumnType.TEXT)]
    [DataProviderColumn(Uid = "sql_col10", Name = "Column 10", Type = ColumnType.TEXT)]

    class SQLProvider : DataProviderBase
    {
        public void Excute(DataRequest request)
        {
            if (request.Parameters.CheckInputs("sql_username", "sql_password", "sql_database"))
            {
                request.ColumnCount = 10;

                Amakozi.Reporting.Provider.Utils.DatabaseHelper dbHelper = new DatabaseHelper();

                System.Data.IDbCommand cmd = null;
                try
                {
                    dbHelper.username = request.Parameters.GetString("sql_username");
                    dbHelper.password = request.Parameters.GetString("sql_password");
                    dbHelper.database = request.Parameters.GetString("sql_database");

                    int port = 0;
                    if (request.Parameters.CheckInput("sql_port") && Int32.TryParse(request.Parameters.GetString("sql_port"), out port))
                    {
                        dbHelper.port = port;
                    }

                    dbHelper.host = request.Parameters.GetString("sql_server");
                    dbHelper.driver = request.Parameters.GetString("sql_provider");

                    // Get a Connection from the Pool
                    using (System.Data.IDbConnection connection = dbHelper.GetConnection())
                    {
                        // Open the Connection
                        connection.Open();

                        cmd = connection.CreateCommand();
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = request.Parameters.GetString("sql_query");

                        System.Data.IDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                        while (reader.Read())
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                request.setColumn("sql_col" + (i + 1), reader.FieldCount > i ? reader[i] : "");
                            }

                            request.Send();
                        }

                        reader.Close();
                    }


                }
                catch (Exception ex)
                {
                    // Throw Error
                    throw new ProviderException("Error while Executing SQL: " + ex.Message);
                }
            }
        }
    }
}
