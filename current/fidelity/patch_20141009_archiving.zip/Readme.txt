Patch for possible archiving issues

Deployment:

Stop the "SDL Tridon Content Manager" com+ application
Stop the "Amakozi Reporting Service" windows service
Stop the "Tridion Content Manager Services Host" windows service
Stop the "Tridion Content Manager Publisher Service" windows service

Copy included dll file to the following locations:

<Reporting Install>/Core/Providers/Data

<TridionHome>/bin

Restart services


Release Notes:
Additional logging has been added for archiving steps.  These will be logged to the Reporting log file when logging
is set to INFO or DEBUG in the Amakozi.Reporting.Config file located at <TridionHome>/config
