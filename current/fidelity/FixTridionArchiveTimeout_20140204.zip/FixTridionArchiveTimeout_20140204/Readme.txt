- Copy contents of Core to Reporting Service root installation folder
- Copy contents of ProvidersData to Providers/Data folder inside Reporting Service root installation folder
- Copy contents of TridionBin to %TRIDIOn_HOME%\bin (assuming this is the folder where the Reporting Archive Event system extension dll lives)
- Copy contents of ModelBin to Amakozi UI extension Model\bin folder !! Also copy to %TRIDION_HOME%\web\webui\webroot\bin

For reporting system changes to reload:
- Restart Amakozi Reporting Service

For event system dll to reload:
- Restart TcmServiceHost
- Restart TcmPublisher
- Restart Tridion ContentManager com+ app
