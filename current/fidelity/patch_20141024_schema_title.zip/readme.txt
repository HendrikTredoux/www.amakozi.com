Patch for additional default field: schema title

Deployment:

Stop the "SDL Tridon Content Manager" com+ application
Stop the "Amakozi Reporting Service" windows service
Stop the "Tridion Content Manager Services Host" windows service
Add the following fields to the ITEM table in the archiving schema:
SCHEMATITLE NVARCHAR2(255)

Stop the "Tridion Content Manager Publisher Service" windows service

Copy Amakozi.Reporting.Tridion.Archive.dll to the following locations:

<Reporting Install>/Core/Providers/Data

<TridionHome>/bin

Copy Amakozi.Reporting.Provider.Tridion.Fidelity.dll to the following location:
<Reporting Install>/Core/Providers/Data

Restart services

Release Notes:
Make sure to "unblock" dll's which may have been blocked by windows UAC Security Zone.

You will now have 1 additional column available when using the Fidelity Archive Provider: Schema Title
