Patch for additional default fields: publication title, webdavurl, publishurl

Deployment:

Stop the "SDL Tridon Content Manager" com+ application
Stop the "Amakozi Reporting Service" windows service
Stop the "Tridion Content Manager Services Host" windows service
Add the following fields to the ITEM table in the archiving schema:
PUBLICATIONTITLE NVARCHAR2(255)
WEBDAVURL NVARCHAR2(400)
PUBLISHURL NVARCHAR2(400)

Stop the "Tridion Content Manager Publisher Service" windows service

Copy Amakozi.Reporting.Tridion.Archive.dll to the following locations:

<Reporting Install>/Core/Providers/Data

<TridionHome>/bin

Copy Amakozi.Reporting.Provider.Tridion.Fidelity.dll to the following location:
<Reporting Install>/Core/Providers/Data

Restart services

Release Notes:
Make sure to "unblock" dll's which may have been blocked by windows UAC Security Zone.

You will now have 3 additional columns available when using the Fidelity Archive Provider: Publication Title, WebDavUrl, Publish URL
Note that the publish url is a relative url since we don't know the host/app name of the website where the item is published to.