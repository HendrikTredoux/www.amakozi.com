Patch for query definition editor UI

Deployment:

Copy /Editor/Controls/*.* to <Reporting Install>/UI/Amakozi.Reporting.Tridon.Editor/Controls/
Copy /Editor/Views/Scripts/*.* to <Reporting Install>/UI/Amakozi.Reporting.Tridion.Editor/Views/Scripts

Option 1:
Restart IIS

Option 2:
Edit %TRIDION_HOME%/web/webui/webroot/configuration/system.config
Increment "modification" attribute value on the following element:
/Configuration/servicemodel/server

Release Notes:
The query definition editor will now save changes when editing relationships in existing query definitions without having to force a model update through editing the title
