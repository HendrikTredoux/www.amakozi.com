﻿Type.registerNamespace("Amakozi.Reporting.Tridion.Editor.Views");

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition = function QueryDefinition()
{
    Tridion.OO.enableInterface(this, "Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition");
    this.addInterface("Amakozi.Reporting.Tridion.Editor.Views.ReportingItemView");
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.initialize = function QueryDefinition$initialize()
{
    this.callBase("Amakozi.Reporting.Tridion.Editor.Views.ReportingItemView", "initialize");
};

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onDatasourceAdded = function QueryDefinition$onDatasourceAdded(datasource)
{    
    var item = $display.getItem();
    if (item)
    {
        if (!item.getChanged())
        {
            item.setChanged(this);
        }
        item.insertDatasource(datasource);
    }
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onDatasourceRemoved = function QueryDefinition$onDatasourceRemoved(datasource)
{
    var item = $display.getItem();
    if (item)
    {
        if (!item.getChanged())
        {
            item.setChanged(this);
        }
        item.removeDatasource(datasource);
    }
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onDatasourceUpdated = function QueryDefinition$onDatasourceUpdated(updatedObj)
{
    var item = $display.getItem();
    if (item)
    {
        if (!item.getChanged())
        {
            item.setChanged(this);
        }

    }
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onItemValidate = function QueryDefinition$onItemValidate(e)
{
    var c = this.properties.controls;
    var error;

    if (c.title.value.length == 0)
    {
        error = {
            field: c.title,
            message: $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "MandatoryFieldMissing", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "Title")])
        };
        c.TabControl.selectItem("GeneralTab");
    } else
    {
        var InputsTab = c.TabControl.getPage("InputsTab");
        error = InputsTab.getValidationError();
        if (error)
        {
            c.TabControl.selectItem("InputsTab");
        } else
        {
            if ($display.getItem().getDatasources().length == 0)
            {
                error = {
                    field: c.title,                    
                    message: $localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "MandatoryFieldMissing", [$localization.getResource("Amakozi.Reporting.Tridion.Editor.Strings", "Datasource")])
                };
            }
        }
    }

    if (error)
    {
        var QueryDefinition$onItemValidate$onModalPopupUnloaded = function ()
        {
            if (activePopup)
            {
                $evt.removeEventHandler(activePopup, "unload", QueryDefinition$onItemValidate$onModalPopupUnloaded);
            }
            try
            {
                error.field.focus();
            }
            catch (e) { }
        }

        $messages.registerError(error.message, null, null, true, true);
        var activePopup = window.top.activeTridionPopup;
        if (activePopup)
        {
            $evt.addEventHandler(activePopup, "unload", QueryDefinition$onItemValidate$onModalPopupUnloaded);
        }
        return false;
    }
};

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onItemCollectData = function QueryDefinition$onItemCollectData()
{
    this.collectFieldData();
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.updateView = function QueryDefinition$updateView()
{
    var p = this.properties;
    var c = p.controls;

    var item = this.getItem();

    if (item && item.isLoaded())
    {
        var InputsTab = c.TabControl.getPage("InputsTab");
        InputsTab.initialize();
        this.callBase("Amakozi.Reporting.Tridion.Editor.Views.ReportingItemView", "updateView");
        var readOnly = item.isReadOnly() || item.isLoading();
        this.setTextBoxValue(c.title, item.getTitle());
        this.setupRelationshipMapper();
        RelationshipMapper.datasource_added = this.onDatasourceAdded;
        RelationshipMapper.datasource_removed = this.onDatasourceRemoved;
        RelationshipMapper.datasource_updated= this.onDatasourceUpdated;
    }
};

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.setupRelationshipMapper = function QueryDefinition$setupRelationshipMapper()
{

    var item = $display.getItem();
    var datasources = item.getDatasources();
    var relationships = item.getRelationships();
    var filters = item.getFilters();
    if (datasources)
    {
        for (var i = 0; i < datasources.length; i++)
        {
            RelationshipMapper.addDatasource(datasources[i].uid, datasources[i].name, datasources[i].Columns, null, filters);
        }
        for (var i = 0; i < relationships.length; i++)
        {
            try
            {
                RelationshipMapper.addRelationship(relationships[i].source_datasource_uid, relationships[i].target_datasource_uid, relationships[i].source_column, relationships[i].target_column);
            } catch (err) { }
        }
        try
        {
            RelationshipMapper.render();
        } catch (err) { }
    }
}

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.collectFieldData = function QueryDefinition$collectFieldData(field)
{
    var c = this.properties.controls;
    var item = $display.getItem();
    switch (field)
    {
        case c.title:
            item.setTitle(field.value, this);
            break;
        default:
            item.setRelationships(RelationshipMapper.relationships);
            item.setFilters(RelationshipMapper.filters);
            break;
    }
};

Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition.prototype.onValueChanged = function QueryDefinition$onValueChanged(event)
{
    var p = this.properties;
    var c = p.controls;
    var item = this.getItem();
    var eventSource = event.source || $e.srcElement(event);
    this.collectFieldData(eventSource);
};

Tridion.DisplayController.registerView(Amakozi.Reporting.Tridion.Editor.Views.QueryDefinition);