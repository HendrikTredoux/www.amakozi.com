Patch for error when running a datasource with metadata field parametersORA-00918: column ambiguously defined

Deployment:

Stop the "SDL Tridon Content Manager" com+ application
Stop the "Amakozi Reporting Service" windows service
Stop the "Tridion Services Host" windows service

Copy included dll file to the following locations:

<Reporting Install>/Core/Providers/Data

<TridionHome>/bin

Restart services


